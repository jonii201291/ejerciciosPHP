<?php
require_once __DIR__ . '/models/User.php';

$usuarioModel = new Usuario();

$usuario = 'jgamber220';
$password = 'Abc0123456789.';
$dni = '12345678X';

if ($usuarioModel->registrar($usuario, $password, $dni)) {
    echo "Usuario creado correctamente.";
} else {
    echo "Error al crear el usuario.";
}
